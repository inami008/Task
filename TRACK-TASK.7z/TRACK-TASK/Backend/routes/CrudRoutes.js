import express from "express"
import { AllUsers, getData, crudDel , UpdateUser} from "../controller/CrudController.js";


const router = express.Router()

router.post("/Save", AllUsers)
router.get('/getData', getData)
router.delete("/del/:id", crudDel)
router.put("/:updateid",UpdateUser)


export default router;