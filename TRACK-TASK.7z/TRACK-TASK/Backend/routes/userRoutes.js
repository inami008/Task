import express from "express";
import { getUsers } from "../controller/user.js";
import { createUsers,updateUser,deleteUser } from "../controller/user.js";
import { isValidated, validateUser } from "../Middlewares/validator.js ";

const router = express.Router();

router.get("/", getUsers);
router.post("/", validateUser, isValidated, createUsers);
router.put("/:userId", updateUser);
router.delete("/:userId", deleteUser);
export default router;