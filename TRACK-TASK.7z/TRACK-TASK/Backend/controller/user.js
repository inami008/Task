import User from "../model/userModel.js";


export const getUsers = async (req, res) => {
  try {
    const users =await User.find();
    res.status(200).json({ success: true, users });
  } catch (err) {
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};
export const createUsers = async (req, res) => {
  try {
    let { email } = req.body;
    const existingUser = await User.findOne({ email: email });
    if (existingUser) {
      return res
        .status(409)
        .json({ success: false, message: "User already exist" });
    }
    const user = await User.create(req.body); //await is liye lagaya hai take ye line pehle chale bad mai dusri line chale
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ message: "Internal Server Error" });
  }
};




export const updateUser = async (req,res) => {
  try {
const id =req.params.userId ;
const user = await User.findByIdAndUpdate(id ,req.body,{new:true});
res.status(200).json({ success: true, user });

}catch (err) {
  res.status(500).json({success: false, message: "Internal Server Error" });
}
};

export const deleteUser = async (req,res) =>{
  try{
    const id =req.params.userId ;
  const user = await User.findByIdAndDelete(id);
  res.status(200).json({ success: true, user });
  
  }catch (err) {
    res.status(500).json({success: false, message: "Internal Server Error" });
  }
};


