import CrudModel from "../model/CrudModel.js";

export const AllUsers = async (req, res) => {
    try {
        const { name, FatherName, Age, email, PhoneNum } = req.body;


        const use = await CrudModel({ name, FatherName, Age, email, PhoneNum }).save()
        res.status(200).send({
            success: true,
            message: "User Crud Successfully",
            use
        })

    }
    catch (error) {
        console.log(error);
        res.status(500).send({
            success: false,
            message: "Error in Crud Controller"
        })
    }
}


export const getData = async (req, res) => {
    try {
        const use = await CrudModel.find()
        res.status(200).send({
            success: true,
            massage: "Data Get SucessFully",
            use
        })

    }

    catch (error) {
        console.log("error");
        res.status(200).send({
            success: true,
            massage: "Error in getData "
        })
    }
}
export const crudDel = async (req, res) => {
    try {
        const useId = req.params.id;
        await CrudModel.findByIdAndDelete(useId);
        res.status(200).send({
            success: "true",
            message: "User data Deleted Successfully"
        })

    }
    catch {
        console.log(error, "error");
        res.status(500).json({
            success: "false",
            message: "Error in Delete CrudController"
        })

    }
}

export const UpdateUser = async (req,res) => {
    try{
        console.log(req.params);
        const id = req.params.updateid;
       const  user = await CrudModel.findByIdAndUpdate(id,req.body,{new:true})
        res.json({success:true,user})
    }

    catch (err) {
        console.log("ERROR ",err);
        res.status(500).json({success:false,
            massage:"error in UpdateUser"})
    }
    }