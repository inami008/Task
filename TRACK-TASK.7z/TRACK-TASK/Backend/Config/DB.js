import mongoose from "mongoose";

const connectDB = async () => {
    try {
        await mongoose.connect("mongodb://localhost:27017/inam")
        console.log("Database Connected")
    } catch (error) {
        console.log(error);
        res.status(500).send({
            success: true,
          message: "Error in Db Connection Controller"
        })
    }
}


export default connectDB




