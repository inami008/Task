import mongoose from "mongoose";

const CrudSchema = new mongoose.Schema({
  name: String,
  FatherName: String,
  Age: Number,
  email: String,
  PhoneNum: Number,
})
export default mongoose.model("Crud", CrudSchema)