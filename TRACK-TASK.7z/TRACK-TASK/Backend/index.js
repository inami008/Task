
import express from "express"
import cors from "cors"
import CrudRoutes from "./routes/CrudRoutes.js"
import connectDB from "./config/db.js"

connectDB()
const app = express()
const port = 5000

app.use(cors())
app.use(express.json())

app.use('/api/v1', CrudRoutes)

app.listen(port, () => {
    console.log(`Backend is Running ${port}`)
})




































// import express from "express";
// import userRoutes from './routes/userRoutes.js';
// import "./db.js"
// const app = express()
// const part =8000;

// app.use(express.json());
// app.use ("/api/users",userRoutes);
// app.listen (part,()=>{
//     console.log("Server is running on part"+part);
// })
