import React, { useEffect, useState } from "react";
import './Prectice.css'
import axios from "axios";

function Crud() {
  const [formData, setFormData] = useState({
    name: '',
    FatherName: '',
    Age: '',
    email: '',
    PhoneNum: '',
  });

  const [data, setdata] = useState([])

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const handleSave = async (event) => {
    event.preventDefault();
    try {
      const respon = await axios.post('http://localhost:5000/api/v1/Save', formData);
      console.log(respon.data);
      getData()
    } catch (error) {
      console.error("Error:", error);
    }
  };




  const getData = async () => {
    axios.get("http://localhost:5000/api/v1/getData")
      .then((res) => {
        console.log(res, 'res')
        setdata(res.data.use)
      })  
      .catch((err) => {
        console.log(err, "err");
      })
  }
  const del = (id) => {
    axios.delete(`http://localhost:5000/api/v1/del/${id}`)
      .then((res) => {
        getData();
      })
      .catch((error) => {
        console.log(error);
      })
  }

  useEffect(() => {
    getData()
  }, [])

  return (
    <div style={{ height: "100vh", width: "100%" }}>

      <table style={{ border: "2px solid black" }}>
        <thead>
          <tr>
            <th className="thea">Name</th>
            <th className="thea">Age</th>
            <th className="thea">FatherName</th>
            <th className="thea">Phone</th>
            <th className="thea">Email</th>

          </tr>
        </thead>
        <tbody>
          <tr>
            <td><input type="text" name="name" value={formData.name} onChange={handleChange} /></td>
            <td><input type="number" name="Age" value={formData.Age} onChange={handleChange} /></td>
            <td><input type="text" name="FatherName" value={formData.FatherName} onChange={handleChange} /></td>
            <td><input type="number" name="PhoneNum" value={formData.PhoneNum} onChange={handleChange} /></td>
            <td><input type="email" name="email" value={formData.email} onChange={handleChange} /></td>
            <td><button onClick={handleSave}>Save</button></td>

          </tr>
        </tbody>
      </table>

      {data.map((val) => {
        return (

          <table>
            <div className="mainTab">
              <tr>
                <td><div className="inp">{val.name}</div></td>
                <td><div className="inp">{val.Age}</div></td>
                <td><div className="inp">{val.FatherName}</div></td>
                <td><div className="inp">{val.PhoneNum}</div></td>
                <td><div className="inp">{val.email}</div></td>
                <td><div><button onClick={() => del(val._id)}>Delete</button></div></td>
                <td><div><button >Edit</button></div></td>
              </tr>

            </div>

          </table>


        )
      })}
    </div>
  );
}

export default Crud;